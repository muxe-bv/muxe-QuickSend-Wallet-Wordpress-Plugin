<?php
/**
* Plugin Name: MUXE QuickSend Wallet
* Plugin URI: https://www.muxe.io/showcase/quicksend-muxe-wallet-widget/
* Description: The MUXE QuickSend Wallet is an opensourced decentralised wallet solution that connects with the Swap Online Wallet Widgetised toolkit
* Version: 1.2
* Author: Jaimy de Vries
* Author URI: https://www.linkedin.com/in/jaimydevries
**/

defined( 'ABSPATH' ) or die( 'Please do not try to attempt something illegal!' );

add_shortcode( 'muxe_quicksend_wallet', 'muxe_quicksend_wallet' );
function muxe_quicksend_wallet() {
    include'windex.html';
}

?>