=== MUXE QuickSend Wallet ===
Contributors: (Jaimy de Vries)
Donate link: https://www.muxe.io/donations
Tags: cryptocurrency wallet, cryptocoins, bitcoin, muxe tokens, muxe, ethereum, usdt, crypto wallet, wallet, crypto exchange, exchange, coin exchange
Requires at least: 4.6
Tested up to: 5.2
Stable tag: 5.2
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

The MUXE QuickSend Cryptocurrency wallet allows everyone to start their crypto wallet



== Installation ==

Upload the zip via the wordpress plugin directory or search for the plugin and install it via the Wordpress Plugin Directory directly.
e.g.

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use the Settings->Plugin Name screen to configure the plugin
4. (Make your instructions match the desired user flow for activating and installing your plugin. Include any steps that might be needed for explanatory purposes)
5. Use the shortcode [muxe_quicksend_wallet] anywere you like


== Changelog ==

= 1.2 =
* Added wordpress plugin styling.
* Added shortcode support.
* Added security preventions.


`<?php code(); // goes in backticks ?>`